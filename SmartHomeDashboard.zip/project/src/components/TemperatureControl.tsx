import { useState } from 'react';
import { Thermometer } from 'lucide-react';

export default function TemperatureControl() {
  const [temperature, setTemperature] = useState(24);
  const [isOn, setIsOn] = useState(true);

  const adjustTemperature = (increment: number) => {
    if (isOn) {
      setTemperature(prev => Math.min(Math.max(prev + increment, 16), 30));
    }
  };

  return (
    <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Thermometer className="text-red-500" />
          <h3 className="text-xl font-semibold text-white dark:text-gray-800">Temperature</h3>
        </div>
        <button
          onClick={() => setIsOn(!isOn)}
          className={`px-4 py-2 rounded ${
            isOn ? 'bg-green-500' : 'bg-gray-600'
          } text-white`}
        >
          {isOn ? 'ON' : 'OFF'}
        </button>
      </div>
      <div className="text-4xl font-bold text-white dark:text-gray-800 mb-4 text-center">
        {temperature}°C
      </div>
      <div className="flex space-x-2">
        <button
          onClick={() => adjustTemperature(-1)}
          className="flex-1 py-2 px-4 rounded bg-blue-500 text-white"
          disabled={!isOn}
        >
          -
        </button>
        <button
          onClick={() => adjustTemperature(1)}
          className="flex-1 py-2 px-4 rounded bg-red-500 text-white"
          disabled={!isOn}
        >
          +
        </button>
      </div>
    </div>
  );
}