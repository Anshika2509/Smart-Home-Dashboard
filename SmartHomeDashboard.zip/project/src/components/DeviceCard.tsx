import { Power } from 'lucide-react';
import { Device } from '../types';

export default function DeviceCard({ device }: { device: Device }) {
  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">{device.type}</h3>
        <button
          className={`p-2 rounded-full ${
            device.status ? 'bg-green-500' : 'bg-gray-600'
          }`}
        >
          <Power className="w-6 h-6 text-white" />
        </button>
      </div>
      
      <div className="text-4xl font-bold text-white mb-2">
        {device.value}
        <span className="text-xl ml-1">{device.unit}</span>
      </div>
      
      <p className="text-gray-400">{device.name}</p>
    </div>
  );
}