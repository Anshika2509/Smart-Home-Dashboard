import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

export default function TimerControl() {
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0);

  useEffect(() => {
    let interval: number;
    if (isRunning) {
      interval = setInterval(() => {
        setTime(prevTime => prevTime + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setTime(0);
    setIsRunning(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Clock className="text-blue-500" />
          <h3 className="text-xl font-semibold text-white dark:text-gray-800">Timer</h3>
        </div>
      </div>
      <div className="text-4xl font-bold text-white dark:text-gray-800 mb-4 text-center">
        {formatTime(time)}
      </div>
      <div className="flex space-x-2">
        <button
          onClick={toggleTimer}
          className={`flex-1 py-2 px-4 rounded ${
            isRunning ? 'bg-red-500' : 'bg-green-500'
          } text-white`}
        >
          {isRunning ? 'Stop' : 'Start'}
        </button>
        <button
          onClick={resetTimer}
          className="flex-1 py-2 px-4 rounded bg-gray-600 text-white"
        >
          Reset
        </button>
      </div>
    </div>
  );
}