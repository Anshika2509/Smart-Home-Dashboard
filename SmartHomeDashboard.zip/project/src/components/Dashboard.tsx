import { useState } from 'react';
import DeviceCard from './DeviceCard';
import { Device } from '../types';

const initialDevices: Device[] = [
  {
    id: '1',
    name: 'Samsung Neo',
    type: 'timer',
    status: true,
    value: 12.07,
    unit: 'min'
  },
  {
    id: '2',
    name: 'Samsung Split',
    type: 'temperature',
    status: true,
    value: 24,
    unit: '°C'
  },
  {
    id: '3',
    name: 'Samsung WiFi-3',
    type: 'speed',
    status: true,
    value: 321,
    unit: 'mbps'
  }
];

export default function Dashboard() {
  const [devices] = useState<Device[]>(initialDevices);

  return (
    <div className="flex-1 bg-gray-900 p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <input
          type="search"
          placeholder="Search devices..."
          className="px-4 py-2 rounded bg-gray-800 text-white"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {devices.map((device) => (
          <DeviceCard key={device.id} device={device} />
        ))}
      </div>
    </div>
  );
}