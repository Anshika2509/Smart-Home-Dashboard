import { useState, useEffect } from 'react';
import { Wifi } from 'lucide-react';

export default function SpeedControl() {
  const [isOn, setIsOn] = useState(true);
  const [speed, setSpeed] = useState(100);

  useEffect(() => {
    if (isOn) {
      const interval = setInterval(() => {
        setSpeed(prev => Math.floor(Math.random() * (400 - 50) + 50));
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isOn]);

  return (
    <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Wifi className="text-blue-500" />
          <h3 className="text-xl font-semibold text-white dark:text-gray-800">Network Speed</h3>
        </div>
        <button
          onClick={() => setIsOn(!isOn)}
          className={`px-4 py-2 rounded ${
            isOn ? 'bg-green-500' : 'bg-gray-600'
          } text-white`}
        >
          {isOn ? 'ON' : 'OFF'}
        </button>
      </div>
      <div className="text-4xl font-bold text-white dark:text-gray-800 mb-2 text-center">
        {isOn ? speed : 0}
        <span className="text-xl ml-1">Mbps</span>
      </div>
      <div className="h-2 bg-gray-700 dark:bg-gray-200 rounded">
        <div
          className="h-full bg-blue-500 rounded transition-all duration-500"
          style={{ width: `${(speed / 400) * 100}%` }}
        />
      </div>
    </div>
  );
}