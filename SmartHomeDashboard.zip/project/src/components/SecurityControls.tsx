import { useState } from 'react';
import { Shield, Bell, Lock, Video } from 'lucide-react';

interface SecurityDevice {
  id: string;
  name: string;
  icon: JSX.Element;
  status: boolean;
}

export default function SecurityControls() {
  const [devices, setDevices] = useState<SecurityDevice[]>([
    { id: 'door', name: 'Main Door', icon: <Lock />, status: true },
    { id: 'motion', name: 'Motion Sensors', icon: <Bell />, status: true },
    { id: 'cameras', name: 'Cameras', icon: <Video />, status: true }
  ]);

  const toggleDevice = (id: string) => {
    setDevices(devices.map(device =>
      device.id === id ? { ...device, status: !device.status } : device
    ));
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {devices.map((device) => (
        <div key={device.id} className="bg-gray-800 dark:bg-white p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`p-3 rounded-full ${device.status ? 'bg-green-500' : 'bg-gray-600'}`}>
                {device.icon}
              </div>
              <div>
                <h3 className="text-white dark:text-gray-800 font-semibold">{device.name}</h3>
                <p className={device.status ? 'text-green-500' : 'text-red-500'}>
                  {device.status ? 'Active' : 'Inactive'}
                </p>
              </div>
            </div>
            <button
              onClick={() => toggleDevice(device.id)}
              className={`px-4 py-2 rounded ${
                device.status ? 'bg-green-500' : 'bg-gray-600'
              } text-white`}
            >
              {device.status ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}