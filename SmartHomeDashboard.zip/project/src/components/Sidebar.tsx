import { Home, Tv, Settings, Shield, Layout as LayoutIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Link, useLocation } from 'react-router-dom';

export default function Sidebar() {
  const { user, logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { icon: <Home />, text: 'Home', path: '/' },
    { icon: <LayoutIcon />, text: 'Rooms', path: '/rooms' },
    { icon: <Shield />, text: 'Security', path: '/security' },
    { icon: <Tv />, text: 'CCTV', path: '/cctv' },
    { icon: <Settings />, text: 'Settings', path: '/settings' }
  ];

  return (
    <div className="w-64 bg-gray-800 h-screen p-4">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-white">{user}</h2>
      </div>
      
      <nav className="space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.text}
            to={item.path}
            className={`flex items-center space-x-3 text-gray-300 hover:bg-gray-700 p-2 rounded cursor-pointer ${
              location.pathname === item.path ? 'bg-gray-700' : ''
            }`}
          >
            {item.icon}
            <span>{item.text}</span>
          </Link>
        ))}
      </nav>

      <button
        onClick={logout}
        className="mt-8 w-full bg-red-600 text-white py-2 rounded hover:bg-red-700"
      >
        Logout
      </button>
    </div>
  );
}