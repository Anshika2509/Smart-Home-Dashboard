export interface Device {
  id: string;
  name: string;
  type: 'timer' | 'temperature' | 'speed' | 'light' | 'fan';
  status: boolean;
  value: number;
  unit: string;
  room?: string;
}

export interface Room {
  id: string;
  name: string;
  devices: Device[];
}

export interface User {
  username: string;
  password: string;
}

export interface AuthContextType {
  user: string | null;
  login: (username: string, password: string) => void;
  logout: () => void;
}