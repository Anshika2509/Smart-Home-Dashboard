import { useState } from 'react';
import { Video, Maximize2 } from 'lucide-react';

const cameras = [
  {
    id: 1,
    name: 'Front Door',
    status: 'Online',
    url: 'https://images.unsplash.com/photo-1558036117-15d82a90b9b1?auto=format&fit=crop&w=1280&h=720'
  },
  {
    id: 2,
    name: 'Back Door',
    status: 'Online',
    url: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1280&h=720'
  },
  {
    id: 3,
    name: 'Garden',
    status: 'Online',
    url: 'https://images.unsplash.com/photo-1558293842-c0fd3db86157?auto=format&fit=crop&w=1280&h=720'
  },
  {
    id: 4,
    name: 'Garage',
    status: 'Online',
    url: 'https://images.unsplash.com/photo-1486006920555-c77dcf18193c?auto=format&fit=crop&w=1280&h=720'
  }
];

export default function CCTVPage() {
  const [selectedCamera, setSelectedCamera] = useState(cameras[0]);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-white dark:text-gray-800 mb-8">CCTV Monitoring</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-gray-800 dark:bg-white p-4 rounded-lg">
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
              <img
                src={selectedCamera.url}
                alt={selectedCamera.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex items-center space-x-2">
                <Video className="text-red-500" />
                <span className="text-white">{selectedCamera.name}</span>
              </div>
              <button
                onClick={toggleFullscreen}
                className="absolute bottom-4 right-4 p-2 bg-gray-700 rounded-lg hover:bg-gray-600"
              >
                <Maximize2 className="text-white" />
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {cameras.map(camera => (
            <button
              key={camera.id}
              onClick={() => setSelectedCamera(camera)}
              className={`w-full p-4 rounded-lg ${
                selectedCamera.id === camera.id ? 'bg-blue-600' : 'bg-gray-800 dark:bg-white'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className={`${
                  selectedCamera.id === camera.id ? 'text-white' : 'text-white dark:text-gray-800'
                }`}>{camera.name}</span>
                <span className="text-green-500">{camera.status}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}