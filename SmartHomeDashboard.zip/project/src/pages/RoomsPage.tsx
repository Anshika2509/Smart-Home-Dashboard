import { useState } from 'react';
import { Lightbulb, Fan } from 'lucide-react';

interface RoomDevice {
  id: string;
  type: 'light' | 'fan';
  status: boolean;
}

interface Room {
  id: string;
  name: string;
  devices: RoomDevice[];
}

const initialRooms: Room[] = [
  {
    id: '1',
    name: 'Living Room',
    devices: [
      { id: 'l1', type: 'light', status: false },
      { id: 'f1', type: 'fan', status: false }
    ]
  },
  {
    id: '2',
    name: 'Kitchen',
    devices: [
      { id: 'l2', type: 'light', status: false },
      { id: 'f2', type: 'fan', status: false }
    ]
  },
  {
    id: '3',
    name: 'Bedroom',
    devices: [
      { id: 'l3', type: 'light', status: false },
      { id: 'f3', type: 'fan', status: false }
    ]
  },
  {
    id: '4',
    name: 'Bathroom',
    devices: [
      { id: 'l4', type: 'light', status: false }
    ]
  }
];

export default function RoomsPage() {
  const [rooms, setRooms] = useState<Room[]>(initialRooms);

  const toggleDevice = (roomId: string, deviceId: string) => {
    setRooms(rooms.map(room => {
      if (room.id === roomId) {
        return {
          ...room,
          devices: room.devices.map(device => 
            device.id === deviceId 
              ? { ...device, status: !device.status }
              : device
          )
        };
      }
      return room;
    }));
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-white mb-8">Rooms</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {rooms.map(room => (
          <div key={room.id} className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-xl font-bold text-white mb-4">{room.name}</h2>
            <div className="flex space-x-4">
              {room.devices.map(device => (
                <button
                  key={device.id}
                  onClick={() => toggleDevice(room.id, device.id)}
                  className={`p-4 rounded-lg flex items-center space-x-2 ${
                    device.status ? 'bg-green-500' : 'bg-gray-700'
                  }`}
                >
                  {device.type === 'light' ? <Lightbulb /> : <Fan />}
                  <span className="text-white">
                    {device.type.charAt(0).toUpperCase() + device.type.slice(1)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}