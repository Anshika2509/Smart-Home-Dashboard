import { useState, useEffect } from 'react';
import { Clock, Thermometer, Wifi } from 'lucide-react';
import TimerControl from '../components/TimerControl';
import TemperatureControl from '../components/TemperatureControl';
import SpeedControl from '../components/SpeedControl';

interface Activity {
  id: number;
  message: string;
  timestamp: Date;
}

export default function HomePage() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Simulated activity log
    const initialActivities = [
      { id: 1, message: 'Living Room Lights turned on', timestamp: new Date(Date.now() - 2 * 60000) },
      { id: 2, message: 'Kitchen Fan turned off', timestamp: new Date(Date.now() - 15 * 60000) },
      { id: 3, message: 'Temperature adjusted to 24°C', timestamp: new Date(Date.now() - 60 * 60000) },
      { id: 4, message: 'Motion detected in Garden', timestamp: new Date(Date.now() - 90 * 60000) },
      { id: 5, message: 'Front Door Camera activated', timestamp: new Date(Date.now() - 120 * 60000) }
    ];
    setActivities(initialActivities);
  }, []);

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return `${seconds} seconds ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} mins ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-white dark:text-gray-800">Welcome Home</h1>
        <div className="text-xl text-white dark:text-gray-800">
          {currentTime.toLocaleTimeString()}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <TimerControl />
        <TemperatureControl />
        <SpeedControl />
      </div>

      <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
        <h2 className="text-xl font-bold text-white dark:text-gray-800 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex justify-between items-center text-gray-300 dark:text-gray-600">
              <span>{activity.message}</span>
              <span>{formatTimeAgo(activity.timestamp)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}