import { useState } from 'react';
import { Shield } from 'lucide-react';
import SecurityControls from '../components/SecurityControls';

export default function SecurityPage() {
  const [recentAlerts] = useState([
    { id: 1, message: 'Front door opened', time: '2 mins ago' },
    { id: 2, message: 'Motion detected in backyard', time: '15 mins ago' },
    { id: 3, message: 'Window sensor triggered', time: '1 hour ago' }
  ]);

  return (
    <div className="p-8">
      <div className="flex items-center space-x-4 mb-8">
        <Shield className="w-8 h-8 text-green-500" />
        <h1 className="text-2xl font-bold text-white dark:text-gray-800">Security System</h1>
      </div>

      <SecurityControls />

      <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
        <h2 className="text-xl font-bold text-white dark:text-gray-800 mb-4">Recent Alerts</h2>
        <div className="space-y-4">
          {recentAlerts.map((alert) => (
            <div key={alert.id} className="flex justify-between items-center text-gray-300 dark:text-gray-600">
              <span>{alert.message}</span>
              <span>{alert.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}