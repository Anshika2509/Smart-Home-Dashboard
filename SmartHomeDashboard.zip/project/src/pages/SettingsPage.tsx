import { useState } from 'react';
import { Settings, Bell, Shield, User, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function SettingsPage() {
  const [notifications, setNotifications] = useState(true);
  const [autoLock, setAutoLock] = useState(true);
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <div className="p-8">
      <div className="flex items-center space-x-4 mb-8">
        <Settings className="w-8 h-8 text-blue-500" />
        <h1 className="text-2xl font-bold text-white dark:text-gray-800">Settings</h1>
      </div>

      <div className="space-y-6">
        <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
          <h2 className="text-xl font-bold text-white dark:text-gray-800 mb-4">User Preferences</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Bell className="text-gray-400" />
                <span className="text-white dark:text-gray-800">Notifications</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications}
                  onChange={() => setNotifications(!notifications)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 dark:bg-gray-200 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Moon className="text-gray-400" />
                <span className="text-white dark:text-gray-800">Dark Mode</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isDarkMode}
                  onChange={toggleTheme}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 dark:bg-gray-200 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="text-gray-400" />
                <span className="text-white dark:text-gray-800">Auto-Lock System</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoLock}
                  onChange={() => setAutoLock(!autoLock)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 dark:bg-gray-200 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 dark:bg-white p-6 rounded-lg">
          <h2 className="text-xl font-bold text-white dark:text-gray-800 mb-4">Profile Settings</h2>
          <div className="flex items-center space-x-4">
            <div className="p-4 bg-gray-700 dark:bg-gray-200 rounded-full">
              <User className="text-gray-400" />
            </div>
            <div>
              <h3 className="text-white dark:text-gray-800 font-semibold">Demo User</h3>
              <p className="text-gray-400">demo@example.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}